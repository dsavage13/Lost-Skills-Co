let currentIndex = 0;

// Ensure scrollLeft and scrollRight are defined in the global scope
function leftScroll() {
    console.log("Scroll Left button clicked");
    const wrapper = document.querySelector('.featured-products-wrapper');
    if (!wrapper) {
        console.error("Wrapper not found!");
        return;
    }

    const totalProducts = wrapper.children.length;

    if (currentIndex > 0) {
        currentIndex--;
    } else {
        currentIndex = totalProducts - 1;
    }

    const offset = -currentIndex * 100;
    wrapper.style.transform = `translateX(${offset}%)`;
}

function scrollRight() {
    console.log("Scroll Right button clicked");
    const wrapper = document.querySelector('.featured-products-wrapper');
    const totalProducts = wrapper.children.length;

    if (currentIndex < totalProducts - 1) {
        currentIndex++;
    } else {
        currentIndex = 0;
    }

    const offset = -currentIndex * 100;
    wrapper.style.transform = `translateX(${offset}%)`;
}

