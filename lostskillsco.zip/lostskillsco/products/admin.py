from django.contrib import admin
from .models import Product

# Register your models here.

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'price', 'is_featured')  # Display the is_featured field
    list_filter = ('is_featured',)  # Add a filter for featured products