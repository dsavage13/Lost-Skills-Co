from django.urls import path
from pages import views
from django.contrib.auth.views import LogoutView, LoginView
from pages.views import logout_view

urlpatterns = [
    path('', views.homeView, name='home'),
    path('about/', views.aboutView, name='about'),
    path('featured/', views.featured_products_view, name='featured_products'),  # Added for featured products
    path('contact/', views.contact_view, name='contact'),  # Added for contact form submission
    path('logout/', LogoutView.as_view(template_name='registration/logout.html'), name='logout'),
    path('login/', LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('category/<str:category_name>/', views.category_products, name='category_products'),
]