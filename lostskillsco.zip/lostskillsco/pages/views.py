from django.shortcuts import render, redirect, get_object_or_404
from django.core.mail import send_mail
from django.conf import settings
from products.models  import Product, Category
from django.template.loader import render_to_string
from .forms import ContactForm
from django.contrib.auth import logout


# Create your views here.
def homeView(request):
    featured_products = Product.objects.filter(is_featured=True)  # Get featured products
    return render(request, 'pages/home.html', {'featured_products': featured_products})

def aboutView(request):
    return render(request, 'pages/about.html')

def featured_products_view(request):
    featured_products = Product.objects.filter(is_featured=True)  # Filter featured products
    return render(request, 'pages/featured.html', {'featured_products': featured_products})

def category_view(request, category_slug):
    products = Product.objects.filter(category__slug=category_slug)
    return render(request, 'pages/category.html', {'products': products})

def contact_view(request):
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            print("Valid Form")
            
            #Clean Data
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            
            message_body = render_to_string('pages/email.html', request.POST)
            
            # Send Email
            send_mail(
                "Portfolio Email",
                name,
                message,
                email,
                ['savagedamian99@gmail.com'],
                html_message=message_body,
            )
            
        else:
            print("Invalid Form")
            
    else:
        form = ContactForm()
        
    return render(request, 'pages/contact.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')  # Redirect to the home page after logout

def category_products(request, category_name):
    # Get the category object
    category = get_object_or_404(Category, name=category_name)
    
    # Filter products by the selected category
    products = Product.objects.filter(category=category)
    
    return render(request, 'products/category_products.html', {
        'category': category,
        'products': products,
    })